Created testbench block1_tb area
