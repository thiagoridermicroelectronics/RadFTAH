Created RTL area of block1
