Created first block root directory
